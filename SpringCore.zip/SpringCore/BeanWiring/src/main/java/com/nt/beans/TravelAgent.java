package com.nt.beans;

public class TravelAgent {
	private TourPlan tp;
	public TravelAgent() {
		System.out.println("O :param Constructor");
	}
	public TravelAgent(TourPlan tp) {
		
	System.out.println("TravelAgent.1: param TravelAgent()");
		this.tp = tp;
	}
	public void setTp(TourPlan tp) {
		this.tp = tp;
	}
	@Override
	public String toString() {
		return "TravelAgent [tp=" + tp + "]";
	}
	

}

package com.nt.beans;

import java.util.Arrays;

public class TourPlan {
private String[] place;

public void setPlace(String[] place) {
	this.place = place;
}

@Override
public String toString() {
	return "TourPlan [place=" + Arrays.toString(place) + "]";
}

}

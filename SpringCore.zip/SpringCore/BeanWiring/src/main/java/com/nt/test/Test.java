package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.nt.beans.TravelAgent;

public class Test {

	public static void main(String[] args) {
		// Create IOC  Container
		
		
		BeanFactory fac=new XmlBeanFactory(new FileSystemResource("src/com/nt/cfgs"));
	
	 // get bean 
		 TravelAgent t=(TravelAgent) fac.getBean("a3");
		 System.out.println(t);
	
	}

}

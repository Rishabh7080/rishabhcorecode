package com.nt.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.scope.Empolyee;

public class ClintTest {

	public static void main(String[] args) {
		ApplicationContext con=new ClassPathXmlApplicationContext("beans.xml");
		 Empolyee me =con.getBean("message",Empolyee.class);
     me.setId(100);
     me.setName("rishabh");
     System.out.println(me.getId()+"\t"+me.getName());
     System.out.println(" _________________________________");
     Empolyee me1 =con.getBean("message",Empolyee.class);
     
     System.out.println(me1.getId()+"\t"+me1.getName());
     
     
	}

}

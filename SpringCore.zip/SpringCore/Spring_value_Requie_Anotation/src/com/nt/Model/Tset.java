package com.nt.Model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Tset {

	public static void main(String[] args) {
		// Create IOC container
		ApplicationContext context=null;
		context=new ClassPathXmlApplicationContext("beans.xml");
		Student student=context.getBean("student",Student.class);
		System.out.println(student);
        student.disp();
		
	}

}

package com.nt.domain;

public class MathCheat {
	public void mathCheat() {
		System.out.println("cheating start");
	}

}

package com.nt.domain;

public class Student {
private int id;
private MathCheat mathCheat;
public void setId(int id) {
	this.id = id;
}
public void setMathCheat(MathCheat mathCheat) {
	this.mathCheat = mathCheat;
}
public void disp()
{
	mathCheat.mathCheat();
	System.out.println("hey my id is "+id+" and do what do you want");
}
}

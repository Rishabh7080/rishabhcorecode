package com.nt.domain;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		//create Ioc container
		ApplicationContext context=null;
		 AnotherStudent ano=null;
		context=new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("bena.xml is loded");
		Student stud=context.getBean("stu",Student.class);
             stud.disp();
             
          ano=context.getBean("another" ,AnotherStudent.class);
            ano.disp1();

	}
}

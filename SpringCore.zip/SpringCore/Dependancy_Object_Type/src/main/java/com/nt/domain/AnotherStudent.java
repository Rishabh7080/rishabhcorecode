package com.nt.domain;

public class AnotherStudent {

	private MathCheat cheat;

	public void setCheat(MathCheat cheat) {
		this.cheat = cheat;
	}
        public void disp1() {
	    cheat.mathCheat();
}
    
}

package com.nt.bean;

public class Viechle {
private int id;
private Engine engine;
public void setId(int id) {
	this.id = id;
}
public void setEngine(Engine engine) {
	this.engine = engine;
}
@Override
public String toString() {
	return "Viechle [id=" + id + ", engine=" + engine + "]";
}

}

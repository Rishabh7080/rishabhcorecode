package com.nt.test;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.bean.Viechle;

public class Test
{
public static void main(String[] args)
{
	// craete Ioc conatiner
	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	
	    Viechle v=context.getBean("viechle",Viechle.class);
	    System.out.println(v);
	
	





}
}

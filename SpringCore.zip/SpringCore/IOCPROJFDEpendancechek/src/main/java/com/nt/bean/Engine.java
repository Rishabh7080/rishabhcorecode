package com.nt.bean;

public class Engine {
	private String type;

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Engine [type=" + type + "]";
	}
	

}

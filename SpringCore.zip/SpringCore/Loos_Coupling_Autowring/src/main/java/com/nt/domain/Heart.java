package com.nt.domain;

public class Heart {

	public void pump() {
		System.out.println("heart is Alive");
		System.out.println("Alive is there");
	}
}

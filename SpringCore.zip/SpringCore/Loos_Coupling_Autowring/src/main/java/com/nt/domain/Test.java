package com.nt.domain;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		//create Ioc container
		ApplicationContext context=null;
		
		context = new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("bena.xml is loded");
		Human h1 =context.getBean("heart",Human.class);
            h1.StartPumping();
             
          
	}
}

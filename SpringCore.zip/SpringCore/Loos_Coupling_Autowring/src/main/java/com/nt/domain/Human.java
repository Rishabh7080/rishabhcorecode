package com.nt.domain;

public class Human {
	private Heart heart;
	
	public Human() {
		System.out.println("O pram cons");
	}
	public Human(Heart heart) {
		super();
		this.heart = heart;
	}
	public void setHeart(Heart heart) {
		this.heart = heart;
	}
public void StartPumping()
{
	if(heart!=null)
	{
	heart.pump();
	}
	else
	{
		System.out.println("dead");
	}
}
}

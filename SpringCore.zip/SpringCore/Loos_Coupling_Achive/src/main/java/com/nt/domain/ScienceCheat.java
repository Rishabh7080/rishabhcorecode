package com.nt.domain;

public class ScienceCheat implements Cheat {

	@Override
	public void cheat() {
		System.out.println("ScienceCheat Started");
		
	}

}

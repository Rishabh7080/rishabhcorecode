package com.nt.domain;

public class MathCheat implements Cheat{
	
	@Override
	public void cheat() {
		System.out.println("mathCheat is Started");
		
	}

}

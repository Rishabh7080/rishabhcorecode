package com.nt.domain;

public interface Cheat {
	public void cheat();
	
	

}

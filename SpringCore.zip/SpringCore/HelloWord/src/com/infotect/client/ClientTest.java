package com.infotect.client;



import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.infotect.model.Message;

public class ClientTest {

	public static void main(String[] args) {
		//Resource resource=new ClassPathResource("Beans.xml") ;
		//BeanFactory b=new XmlBeanFactory(resource);
		ApplicationContext context =new ClassPathXmlApplicationContext("Beans.xml");
	Object object=context.getBean("message");
	if(object !=null) 
	{
		Message message=(Message)object;
		System.out.println(message.getMessageID()+"\t"+message.getMessage());
		
	
	}
System.out.println("---------------------------");
Message message=context.getBean("message",Message.class);
System.out.println(message.getMessageID()+"\t"+message.getMessage());

	}

}

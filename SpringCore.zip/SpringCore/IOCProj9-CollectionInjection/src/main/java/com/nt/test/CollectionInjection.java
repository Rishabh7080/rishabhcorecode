package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.beans.CollegeDetails;
import com.nt.beans.StudentDetails;

public class CollectionInjection {

	public static void main(String[] args) {
		BeanFactory factory=null;
		StudentDetails st=null;
		CollegeDetails dt=null;
		// Create IOC container
		
	factory = new  ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml");

	st=	factory.getBean("stDetails",StudentDetails.class);
	System.out.println(st);

		System.out.println("--------------------------------------");
		
		dt=factory.getBean("clgDetatil",CollegeDetails.class);
		System.out.println(dt);
	}

}

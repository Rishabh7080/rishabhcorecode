package com.nt.beans;

import java.util.Arrays;
import java.util.Date;

public class StudentDetails 
{
private int marks[];
private  Date impDates[];
public StudentDetails() {
System.out.println("0 param constructor ");
}
public void setMarks(int[] marks) 
{
	this.marks = marks;
}
public void setImpDates(Date[] impDates) {
	this.impDates = impDates;
}
@Override
public String toString() {
	return "StudentDetails [marks=" + Arrays.toString(marks) + ", impDates=" + impDates + "]";
}
}

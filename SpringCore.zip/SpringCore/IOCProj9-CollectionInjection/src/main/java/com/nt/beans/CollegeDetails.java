package com.nt.beans;

import java.util.Date;
import java.util.List;

public class CollegeDetails {
	private List<String> StudentName;
	private List<Date> impDates;
	public void setStudentName(List<String> studentName) {
		StudentName = studentName;
	}
	public void setImpDates(List<Date> impDates) {
		this.impDates = impDates;
	}
	@Override
	public String toString() {
		return "CollegeDetails [StudentName=" + StudentName + ", impDates=" + impDates + "]";
	}
	
}

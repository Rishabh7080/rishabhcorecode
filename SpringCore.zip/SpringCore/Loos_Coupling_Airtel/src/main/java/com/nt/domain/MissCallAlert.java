package com.nt.domain;

public class MissCallAlert implements Service {

	@Override
	public void service() {
		System.out.println("missCall service Activated");
		
	}

}

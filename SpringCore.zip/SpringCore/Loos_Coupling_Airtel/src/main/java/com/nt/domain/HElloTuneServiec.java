package com.nt.domain;

public class HElloTuneServiec  implements Service{

	@Override
	public void service() {
		System.out.println("Hello tune is activated ");
	}

}

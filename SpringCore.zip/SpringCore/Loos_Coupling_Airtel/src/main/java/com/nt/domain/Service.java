package com.nt.domain;

public interface Service {
public void service();
}

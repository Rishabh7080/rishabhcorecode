package com.nt.domain;

public class Airtel {
	private Service service;

	public void setService(Service service) {
		this.service = service;
	}
	public void Activate()
	{
		service.service();
	}

}

package com.nt.domain;

public class DataService implements Service{

	@Override
	public void service() {
		System.out.println("Data service is Activated");
	}

}

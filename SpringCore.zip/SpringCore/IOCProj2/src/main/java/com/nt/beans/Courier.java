package com.nt.beans;

public interface Courier {
public String deliver(int orderid);
}

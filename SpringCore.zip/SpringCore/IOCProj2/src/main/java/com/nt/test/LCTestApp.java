package com.nt.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.nt.beans.FlipKart;

public class LCTestApp {
public static void main(String[] args) {
	// Create BeanFactory  Object to create IOC container
	BeanFactory factory=new  XmlBeanFactory(new FileSystemResource("src/main/java/com/nt/cfgs/applicationContext.xml"));


FlipKart bean=factory.getBean("fpk",FlipKart.class);
          String bi=bean.Purchse(new String[] {"shirt","mobile","pen"});
          System.out.println(bi+" \t");

}
}

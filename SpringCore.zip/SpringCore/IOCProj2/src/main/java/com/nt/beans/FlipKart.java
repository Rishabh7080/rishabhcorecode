package com.nt.beans;

import java.util.Random;

public class FlipKart {
private Courier courier;
public FlipKart() {
	System.out.println("o parAM cons");
}
public void setCourier(Courier courier) {
	System.out.println("FlipKart.setCourir(-)");
	this.courier = courier;
}
 
public String Purchse(String item[])
{
	//Generate  OrderId;
	Random rad=new Random();
	int orderid=rad.nextInt(700);
	// Delver order
	String status=courier.deliver(orderid);
	return status+"bill Amt of orderid"+orderid+"is 700";
}

}

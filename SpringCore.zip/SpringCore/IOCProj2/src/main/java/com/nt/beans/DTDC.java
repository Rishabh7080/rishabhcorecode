package com.nt.beans;

public class DTDC implements Courier {
public DTDC() {
	System.out.println("DTDC:0 Param Constructor");
}
	@Override
	public final String deliver(int orderid) {
		return "BlueDart is raedy to deliver the Product of"+orderid;
	}

}

package com.nt.beans;

public class BlueDart implements Courier {

	public BlueDart()
	{
		System.out.println("Blue Dart:O paramContructor");
	}
	@Override
	public final String deliver(int orderid) {
		// TODO Auto-generated method stub
		return "BlueDart is raedy to deliver the Product of"+orderid;
	}

}

package com.nt.model;

public class Principal {
 public void principalInfo()
 {
	 System.out.println(" am your principal");
	 System.out.println("my name is Rishbhs");
 }
}

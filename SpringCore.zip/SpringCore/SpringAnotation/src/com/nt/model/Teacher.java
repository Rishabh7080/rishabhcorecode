package com.nt.model;

public interface Teacher {
 public void teach();
}

package com.nt.model;

import org.springframework.stereotype.Component;

//@Component("collegBean")
public class College {
private Principal principal;
private Teacher teach;

	// using contructor
//	public College(Principal principal) {
//	super();
//	this.principal = principal;}



public void setTeach(Teacher teach) {
	this.teach = teach;
}



// using seeter method
public void setPrincipal(Principal principal) {
	this.principal = principal;
}



	public void test()
	{   principal.principalInfo();
	teach.teach();
		System.out.println("methos is call");
	}
}

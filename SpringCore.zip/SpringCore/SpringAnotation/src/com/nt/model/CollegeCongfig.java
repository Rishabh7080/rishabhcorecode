package com.nt.model;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.nt.model")
 class CollegeCongfig {
	
	public Teacher techerinfo()
	{
		return new MathTeacher();
	}
	@Bean
	public Principal principalBean()
	{
		return new Principal();
	}
	@Bean(name = {"CollegeBean","callBeam"})
	
	public College CollegeBean() {
		//using constrictor 
		//College col=new College(principalBean());
		
		//useing setteror method
    College col=new College();
    
    col.setPrincipal(principalBean());
    
    col.setTeach(techerinfo());
		return col;
	}

}

package com.nt.model;

public class MathTeacher implements Teacher {

	@Override
	public void teach() {
		System.out.println("am your math Teacher");
		System.out.println("my name is Pintu shukla");
		
	}

}

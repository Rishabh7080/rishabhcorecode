package com.nt.beans;

public class Empolyee {
private int id;
private String name;

public Empolyee(int id, String name) {
	System.out.println("Empolyee.Empolyee()");
	this.id = id;
	this.name = name;
}

public void show(){  
    System.out.println(id+" "+name);  
}

}

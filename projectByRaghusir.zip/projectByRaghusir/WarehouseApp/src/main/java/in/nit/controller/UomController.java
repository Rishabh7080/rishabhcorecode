package in.nit.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.nit.model.ShipmentType;
import in.nit.model.Uom;
import in.nit.service.IUomTypeService;

@Controller
@RequestMapping("/uom")
public class UomController {

	@Autowired
	private IUomTypeService service;

	// 1 show Register
	@GetMapping("/register")
	public String showRegister(Model model) {
		model.addAttribute("uom", new Uom());
		return "UomRegister";
	}

	// 2 save: on click submit

	@PostMapping("/save")
	public String save(
			// read from data Ui (given by container)
			@ModelAttribute Uom uom, Model model)// to send data Ui

	{
		// perfrom Save Opertion
		Integer id = service.saveUom(uom);
		// construct one message
		String message = "UomType'" + id + "' saved successfully";
		// send to Ui
		model.addAttribute("message", message);
		return "UomRegister";
	}

	// 3. display all recard
	@GetMapping("/all")
	public String fetchAll(Model model) {
         List<Uom> list= service.getAllUom();	
         model.addAttribute("list", list);
		return "UomData";
	}

	
	 // 4removeby Id
	@GetMapping("/delete/{id}")
	public String removeById(@PathVariable Integer id, Model model) {
		String msg = null;
		if (service.isExistUom(id)) {
			service.deleteUom(id);
			msg = "Uom '" + id + "' deleted!";

		} else {
			msg = "Uom '" + id + "' Not exist!";
		}

		model.addAttribute("message", msg);
		// show other rows
		List<Uom> list = service.getAllUom();
		model.addAttribute("list", list);

		return "UomData";
	}
	
	
	// 4.clock on edit
	/**
	 * On click Edit HyperLink at UI,
	 * read one PathVariable and fetch data from 
	 * service, if exist send to edit page
	 * else redirect to data page
	 */
	@GetMapping("/edit/{id}")
	 public String showEdit(@PathVariable Integer id,Model model)
	 {
	   String page=null;
	   Optional<Uom> opt=service.getOneUom(id);

	  if(opt.isPresent()) {
	     Uom um=opt.get();
	     //FORM BACKING OBJECT WITH DATA
	     model.addAttribute("uom", um);
	     page="UomEdit";
	  }else { 
	     //id not exist
	     page="redirect:../all";
	  }
	  return page;
	}
	
	// 6. Update: on click update
		/**
		 * On click update button,read form data and perform update operation
		 * send back to Data page with success message.
		 */
	@PostMapping("/update")
	public String update( @ModelAttribute Uom uom,Model model)
	{
		service.updateUom(uom);
		String msg="UOM '"+uom.getId()+"'Updated !";
		model.addAttribute("message", msg);
		List<Uom> list=service.getAllUom();
		model.addAttribute("list", list);
		return "UomData";
	}
	
	
	
}

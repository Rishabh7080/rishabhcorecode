package in.nit.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.nit.model.Uom;

import in.nit.repo.UomTypeRepository;
import in.nit.service.IUomTypeService;

@Service
public class UomServiceImpl implements IUomTypeService {

	@Autowired
	private UomTypeRepository repo;

	@Transactional
	public Integer saveUom(Uom um) {
		Integer id = repo.save(um).getId();
		return id;
	}

	@Transactional
	public void updateUom(Uom um) {
		repo.save(um);

	}

	@Transactional
	public void deleteUom(Integer id) {
		repo.deleteById(id);

	}

	@Transactional(readOnly = true)
	public Optional<Uom> getOneUom(Integer id) {
		Optional<Uom> opt = repo.findById(id);
		
		return opt;
	}

	@Transactional(readOnly = true)
	public List<Uom> getAllUom() {
		List<Uom> list = repo.findAll();
		return list;
	}

	@Transactional(readOnly = true)
	public boolean isExistUom(Integer id) {
		boolean exist = repo.existsById(id);
		return exist;
	}

}

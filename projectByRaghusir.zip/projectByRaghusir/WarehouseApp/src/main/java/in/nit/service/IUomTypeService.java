package in.nit.service;

import java.util.List;
import java.util.Optional;


import in.nit.model.Uom;


public interface IUomTypeService {

	Integer saveUom(Uom um);

	void updateUom(Uom um);

	void deleteUom(Integer id);

	Optional<Uom> getOneUom(Integer id);;// only one found

	List<Uom> getAllUom();

	boolean isExistUom(Integer id);

	
}

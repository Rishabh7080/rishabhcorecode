package in.nit.service;

import java.util.List;
import java.util.Optional;

import in.nit.model.OrderMethod;

public interface IOrderMethodService {
	Integer saveOrderMethod(OrderMethod om);// save the data

	void updateOrderMethod(OrderMethod om); // update the data

	void deleteOrderMethod(Integer id);// delete the data

	Optional<OrderMethod> getOneOrderMethod(Integer id);;// only one found

	List<OrderMethod> getAllOrderMethods(); // fetch the data

	boolean isOrderMethodExist(Integer id); // its showing data is there or not
}

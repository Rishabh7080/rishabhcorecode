package in.nit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nit.model.Uom;



public interface UomTypeRepository
        extends JpaRepository<Uom,Integer> {

}

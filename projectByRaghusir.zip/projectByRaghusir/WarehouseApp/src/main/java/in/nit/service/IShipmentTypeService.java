 package in.nit.service;

import java.util.List;
import java.util.Optional;

import in.nit.model.ShipmentType;


public interface IShipmentTypeService {

	Integer saveShipmentType(ShipmentType st);// save the data

	void updateShipmentType(ShipmentType st); // update the data

	void deleteShipmentType(Integer id);// delete the data

	Optional<ShipmentType> getOneShipmentType(Integer id);;// only one found
	
	List<ShipmentType> getAllShipmentTypes(); // fetch the data

	boolean isShipmentTypeExist(Integer id); // its showing data is there or not

}
